@echo off
start "" "%~dp0Marker Study.exe"
