/* Tab-separated question entry. Shift+Tab keeps normal keyboard navigation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else {root.MarkerBulkInput=api;api.install(root.document);}})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 function insert(field){if(!field)return;field.setRangeText('\t',field.selectionStart,field.selectionEnd,'end');field.dispatchEvent(new Event('input',{bubbles:true}));field.focus();}
 function keydown(ev){if(ev.target?.id!=='bulk-text'||ev.key!=='Tab'||ev.shiftKey||ev.ctrlKey||ev.altKey||ev.metaKey||ev.isComposing)return;ev.preventDefault();insert(ev.target);}
 function install(doc){doc.addEventListener('keydown',keydown);doc.addEventListener('click',ev=>{if(!ev.target.closest('[data-insert-bulk-tab]'))return;ev.preventDefault();insert(doc.getElementById('bulk-text'));});}
 function parse(text){const rows=[],errors=[];String(text||'').split(/\r?\n/).forEach((line,i)=>{if(!line.trim())return;const split=line.indexOf('\t');if(split<0){errors.push(`${i+1}行目：問題と答えの間にTabを入れてください。`);return;}const q=line.slice(0,split).trim(),a=line.slice(split+1).trim();if(!q||!a){errors.push(`${i+1}行目：問題と答えの両方を入力してください。`);return;}if(q.length>700||a.length>350){errors.push(`${i+1}行目：問題700文字・答え350文字以内にしてください。`);return;}rows.push({q,a});});return {rows,errors};}
 return {insert,keydown,install,parse};
});
