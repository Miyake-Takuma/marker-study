/* Pure validation and image analysis helpers. No network or persistent writes. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerCore=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const date=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T12:00:00Z'))&&new Date(s+'T12:00:00Z').toISOString().slice(0,10)===s;
 const count=v=>Number.isFinite(v)?Math.max(0,Math.floor(v)):0;
 function stats(s={}){
  if(!s||typeof s!=='object'||Array.isArray(s))s={};
  return {seen:count(s.seen),correct:count(s.correct),wrong:count(s.wrong),lastCorrect:date(s.lastCorrect)?s.lastCorrect:null,lastReviewed:date(s.lastReviewed)?s.lastReviewed:null,writtenDays:[...new Set((Array.isArray(s.writtenDays)?s.writtenDays:[]).filter(date))],needsReview:s.needsReview===true,dueAt:date(s.dueAt)?s.dueAt:null,intervalDays:Math.min(365,count(s.intervalDays))};
 }
 const profileIcons=['📚','🌱','🐱','🚀','⭐','🦊','🐧','🌸'];
 function profile(raw){
  const p=raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{};
  return {name:typeof p.name==='string'&&p.name.trim()?p.name.trim().slice(0,30):'学習者',icon:profileIcons.includes(p.icon)?p.icon:'📚',goal:typeof p.goal==='string'?p.goal.trim().slice(0,100):'',image:typeof p.image==='string'&&p.image.length<=100000&&/^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]*={0,2}$/.test(p.image)?p.image:''};
 }
 function database(raw){
  const fail=message=>{throw new Error(message);};
  if(!raw||raw.version!==1||!Array.isArray(raw.decks)||!Array.isArray(raw.exams)||!raw.settings||typeof raw.settings!=='object'||Array.isArray(raw.settings))fail('対応していない保存形式です');
  if(raw.decks.length>300||raw.exams.length>2000)fail('問題集・予定の件数が上限を超えています');
  const ids=new Set();
  function id(value){if(typeof value!=='string'||!value||value.length>150||ids.has(value))fail('IDが重複しているか不正です');ids.add(value);return value;}
  function text(value,max,required=false){if(typeof value!=='string'||value.length>max||(required&&!value.trim()))fail('項目が空か、文字数が上限を超えています');return value;}
  const localFriends=raw.localFriends??[];
  if(!Array.isArray(localFriends)||localFriends.length>200)fail('友達一覧が不正です');
  const friends=localFriends.map(f=>{if(!f||typeof f!=='object')fail('友達が不正です');return {id:id(f.id),name:text(f.name,30,true),icon:profileIcons.includes(f.icon)?f.icon:'🌱'};});
  const friendIds=new Set(friends.map(f=>f.id));
  const decks=raw.decks.map(d=>{
   if(!d||!Array.isArray(d.cards)||d.cards.length>2000)fail('問題データが不正です');
   const pending=d.pending??[];if(!Array.isArray(pending)||pending.length>150)fail('要確認の問題データが不正です');
   const extra={receivedFrom:friendIds.has(d.receivedFrom)?d.receivedFrom:'',pending:pending.map(p=>({id:id(p.id),q:text(p.q??'',700),a:text(p.a,350,true),page:text(p.page??'',20),reason:text(p.reason??'',500)}))};
   if(d.generation){const g=d.generation;if(typeof g!=='object'||Array.isArray(g))fail('自動作成の記録が不正です');extra.generation={provider:text(g.provider,40),model:text(g.model,100),fileName:text(g.fileName??'',200),total:count(g.total),calls:count(g.calls)};}
   return {id:id(d.id),title:text(d.title,100,true),subject:text(d.subject??'その他',50),group:text(d.group??'',60),icon:text(d.icon??'📚',16),createdAt:typeof d.createdAt==='string'?d.createdAt:'',updatedAt:typeof d.updatedAt==='string'?d.updatedAt:'',...extra,cards:d.cards.map(c=>{
    if(!c||typeof c!=='object')fail('問題が不正です');
    const source={};if(c.source){if(!Array.isArray(c.source.markerIds)||c.source.markerIds.length>150)fail('問題の参照情報が不正です');source.source={quote:text(c.source.quote??'',1000),markerIds:c.source.markerIds.map(x=>text(x,80,true))};}
    return {id:id(c.id),q:text(c.q,700,true),a:text(c.a,350,true),explanation:text(c.explanation??'',700),page:text(c.page??'',20),stats:stats(c.stats),...source};
   })};
  });
  const exams=raw.exams.map(x=>{if(!x||!date(x.date))fail('試験日が不正です');return {id:id(x.id),date:x.date,subject:text(x.subject,60,true),range:text(x.range??'',160)};});
  const prefs=raw.settings;
  const windows=(Array.isArray(prefs.windows)?prefs.windows:[]).map(x=>{if(!x||!Number.isInteger(x.day)||x.day<0||x.day>6||!/^([01]\d|2[0-3]):[0-5]\d$/.test(x.time))fail('通知の候補時刻が不正です');return {id:id(x.id),day:x.day,time:x.time};});
  const history=(Array.isArray(raw.history)?raw.history:[]).filter(x=>x&&date(x.date)&&typeof x.id==='string').slice(-50).map(x=>({id:x.id,date:x.date,good:count(x.good),total:count(x.total),deckTitle:String(x.deckTitle||'').slice(0,100)}));
  return {version:1,decks,exams,localFriends:friends,settings:{profile:profile(prefs.profile),dark:prefs.dark===true,reducedMotion:prefs.reducedMotion===true,notifyEnabled:prefs.notifyEnabled===true,windows,dailyLimit:count(prefs.dailyLimit)||2,aiProvider:['chatgpt','gemini','claude','copilot'].includes(prefs.aiProvider)?prefs.aiProvider:'chatgpt'},counts:{sessions:count(raw.counts?.sessions)},history};
 }
 function yellow(r,g,b,options={}){const difference=options.sensitivity==='sensitive'?8:16;return r>130&&g>110&&Math.min(r,g)-b>difference&&g>r*.7&&r>g*.75;}
 function yellowBoxes(rgba,width,height,options={}){
  const mask=new Uint8Array(width*height),visited=new Uint8Array(mask.length),queue=new Int32Array(mask.length),boxes=[];
  // Downsampled image, local dilation joins letters cut out of a highlighter stroke.
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){
   const i=(y*width+x)*4;if(!yellow(rgba[i],rgba[i+1],rgba[i+2],options))continue;
   for(let dy=-1;dy<=1;dy++)for(let dx=-2;dx<=2;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&xx<width&&yy>=0&&yy<height)mask[yy*width+xx]=1;}
  }
  for(let i=0;i<mask.length;i++){
   if(!mask[i]||visited[i])continue;
   let head=0,tail=1,minX=i%width,maxX=minX,minY=Math.floor(i/width),maxY=minY;queue[0]=i;visited[i]=1;
   while(head<tail){const p=queue[head++],x=p%width,y=Math.floor(p/width);minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);
    const next=[];if(x)next.push(p-1);if(x<width-1)next.push(p+1);if(y)next.push(p-width);if(y<height-1)next.push(p+width);
    for(const n of next)if(mask[n]&&!visited[n]){visited[n]=1;queue[tail++]=n;}
   }
   if(tail>=Math.max(20,width*height*0.00006)&&maxX-minX>=5&&maxY-minY>=2)boxes.push({x:minX,y:minY,width:maxX-minX+1,height:maxY-minY+1});
  }
  return boxes.sort((a,b)=>a.y-b.y||a.x-b.x).slice(0,150);
 }
 function clipText(text,x,width,rects,measure){
  const chars=Array.from(text),advances=chars.map((_,i)=>measure(chars.slice(0,i+1).join(''))),total=advances.at(-1)||1;
  return chars.filter((char,i)=>{const before=i?advances[i-1]:0,center=x+(before+advances[i])/2/total*width;return rects.some(r=>center>=r[0]&&center<=r[2]);}).join('').trim();
 }
 return {database,profile,profileIcons,stats,yellow,yellowBoxes,clipText};
});
