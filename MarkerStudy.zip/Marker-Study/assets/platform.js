/* Progressive installation and offline support; startup never waits for this file. */
(()=>{
 'use strict';
 let installPrompt=null,ready=false,waitingWorker=null,saveFailed=false;
 const secure=location.protocol==='https:'||location.hostname==='localhost'||location.hostname==='127.0.0.1';
 function status(){document.querySelectorAll('[data-offline-status]').forEach(x=>x.textContent=ready?'オフライン準備完了':secure?'初回の保存を準備中':'HTTPSで公開すると利用できます');document.querySelectorAll('[data-update-app]').forEach(x=>x.hidden=!waitingWorker);const el=document.getElementById('connection-status');if(el)el.textContent=saveFailed?'保存できていません':navigator.onLine?'端末内に保存':'オフライン';}
 window.addEventListener('beforeinstallprompt',ev=>{ev.preventDefault();installPrompt=ev;status();});
 window.addEventListener('appinstalled',()=>{installPrompt=null;status();});
 window.addEventListener('online',status);window.addEventListener('offline',status);
 document.addEventListener('marker-render',status);
 async function install(){if(installPrompt){const prompt=installPrompt;installPrompt=null;await prompt.prompt();await prompt.userChoice;}else{document.querySelector('#install-help')?.scrollIntoView({behavior:'smooth'});}}
 window.MarkerPlatform={install,status,setSaveFailed:failed=>{saveFailed=!!failed;status();},isSecure:secure,isStandalone:()=>matchMedia('(display-mode: standalone)').matches||navigator.standalone===true};
 if('serviceWorker' in navigator&&secure){
  window.addEventListener('load',async()=>{
   try{
    const registration=await navigator.serviceWorker.register(new URL('sw.js',document.baseURI).href,{updateViaCache:'none'});
    function waiting(){waitingWorker=registration.waiting;status();}
    waiting();registration.addEventListener('updatefound',()=>{registration.installing?.addEventListener('statechange',waiting);});
    await navigator.serviceWorker.ready;ready=true;status();
   }catch(err){document.querySelectorAll('[data-offline-status]').forEach(x=>x.textContent='準備に失敗しました。オンラインで再読み込みしてください。');console.warn('Offline setup failed',err);}
  });
 }
 // Updates activate only after user request. Never reload a study form automatically.
 document.addEventListener('click',ev=>{if(!ev.target.closest('[data-update-app]')||!waitingWorker)return;if(confirm('入力中の内容を保存・バックアップしてから更新してください。更新しますか？')){navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});waitingWorker.postMessage({type:'ACTIVATE'});}});
})();
