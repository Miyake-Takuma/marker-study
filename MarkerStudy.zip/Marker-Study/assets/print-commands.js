/* Offline, source-bound commands. This is a bounded rule engine, not a language model. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerPrintCommands=api;})(typeof window==='object'?window:globalThis,function(){
'use strict';
function termsFrom(value){
  const terms=Array.isArray(value)?value:String(value||'').split(/[\n,、]/);
  const unique=[...new Set(terms.map(x=>String(x).trim()).filter(Boolean))];
  if(unique.length>50||unique.some(x=>x.length>350))throw Error('答えは50個まで、1個350文字以内で入力してください。');
  return unique;
}
function parse(command,answers=''){
  let raw=String(command||'').trim();
  if(!raw||raw.length>500)throw Error('命令文を1〜500文字で入力してください。下の例も使えます。');
  const quoted=[];
  raw=raw.replace(/「([^「」]+)」|“([^“”]+)”/g,(_,a,b)=>{quoted.push(a||b);return '';});
  let rest=raw.normalize('NFKC'),count=10,quote=false,reverse=false;
  const counts=[...rest.matchAll(/(?:最大)?(\d+)問/g)].map(m=>Number(m[1]));
  if(counts.length>1||counts.some(n=>n<1||n>50))throw Error('問題数は1〜50問で、1か所だけ指定してください。');
  if(counts.length)count=counts[0];
  rest=rest.replace(/(?:最大)?\d+問/g,'');
  rest=rest.replace(/(?:元の文|原文|出典)(?:を)?(?:解説に)?(?:付けて|つけて|付ける|つける)/g,()=>{quote=true;return '';});
  rest=rest.replace(/意味から単語/g,()=>{reverse=true;return '単語と意味';});
  const definition=/定義(?:文)?/.test(rest),vocabulary=/(?:英)?単語と意味|単語帳/.test(rest);
  const cloze=/穴埋め|答え|語句/.test(rest);
  if(Number(definition)+Number(vocabulary)+Number(cloze)>1)throw Error('作り方は1つずつ指定してください。穴埋め・単語と意味・定義文を組み合わせずに実行してください。');
  const mode=definition?'definition':vocabulary?'vocabulary':cloze||quoted.length?'cloze':null;
  rest=rest.replace(/指定した|指定の|英単語と意味|単語と意味|単語帳|定義文|定義|穴埋めカード|穴埋め問題|穴埋め|一問一答|答え|語句|カード化|カード|問題/g,'');
  rest=rest.replace(/作成して(?:ください)?|作って(?:ください)?|作成する|作る|にして(?:ください)?|にする|して(?:ください)?/g,'');
  rest=rest.replace(/[\s、。,，.]/g,'').replace(/から|として|を|で|に|が|の|と/g,'');
  if(!mode||rest)throw Error('この命令には未対応の内容があります。例のボタンから選び、問題数や答えを変えてください。自由な翻訳・重要度の判断はできません。');
  const terms=termsFrom([...termsFrom(answers),...quoted]);
  if(mode==='cloze'&&!terms.length)throw Error('穴埋めの答えを下の欄に1行ずつ入力するか、「光合成」のように命令文で囲んでください。');
  if(mode!=='cloze'&&terms.length)throw Error('答えの指定は穴埋めで使えます。単語・定義文では答え欄を空にしてください。');
  return {mode,count,quote,reverse,terms,label:({cloze:'指定した答えの穴埋め',vocabulary:reverse?'意味 → 単語':'単語 → 意味',definition:'定義文の一問一答'})[mode]};
}
function generate(text,plan,helpers,page=1){
  text=String(text||'');
  if(!text.trim()||text.length>30000)throw Error('読み取り文章を1〜30,000文字で用意してください。');
  const candidates=[],issues=[],groups=new Map();let truncated=false;
  const push=(card,source,group)=>{
    if(card.q.length>700||card.a.length>350||source.length>695){issues.push('長すぎる文があるため候補から外しました。文章を短い文に分けてください。');return;}
    if(candidates.some(x=>x.card.q===card.q&&x.card.a===card.a))return;
    groups.set(group,(groups.get(group)||0)+1);
    if(candidates.length>=200){truncated=true;return;}
    candidates.push({card:{...card,explanation:plan.quote?'原文：'+source:'',page:String(page)},source,group,selected:false});
  };
  if(plan.mode==='cloze'){
    for(const term of plan.terms){
      const matches=helpers.answerOccurrences(text,term);
      if(!matches.length){issues.push('原文に見つかりません：'+term);continue;}
      let added=0;
      for(const match of matches){
        // English words must not match inside a different word (e.g. art / earth).
        if(/^[A-Za-z]/.test(term)&&/[A-Za-z0-9_]/.test(text[match.start-1]||''))continue;
        if(/[A-Za-z]$/.test(term)&&/[A-Za-z0-9_]/.test(text[match.end]||''))continue;
        try{
          const card=helpers.cloze(text,match.start,match.end,page);
          const sentence=card.q.slice(card.q.indexOf('\n')+1);
          if(sentence.toLocaleLowerCase().includes(term.toLocaleLowerCase())){issues.push('同じ文に答えが残るため確認が必要です：'+term);continue;}
          push(card,sentence.replace('（　　　）',card.a),'answer:'+term);added++;
        }catch(_){issues.push('文の長さ・前後関係を確認してください：'+term);}
      }
      if(!added&&!issues.some(x=>x.endsWith('：'+term)))issues.push('単語全体が一致する文がありません：'+term);
    }
  }else if(plan.mode==='vocabulary'){
    let skipped=0;
    for(const line of text.split(/\r?\n/).filter(x=>x.trim())){
      const match=line.trim().match(/^([A-Za-z][A-Za-z '\u2019-]{0,99}?)\s*(?:\t+|[:：]|\s[-–—]\s)\s*(.{1,350})$/);
      if(!match||!/[\u3040-\u30ff\u3400-\u9fff]/.test(match[2])){skipped++;continue;}
      const word=match[1].trim(),meaning=match[2].trim();
      push({q:plan.reverse?'次の意味に合う単語・熟語は？\n'+meaning:'次の単語・熟語の意味は？\n'+word,a:plan.reverse?word:meaning},line.trim(),'word:'+word);
    }
    if(skipped)issues.push(`${skipped}行は「英単語：日本語の意味」の形でないため除外しました。翻訳は補いません。`);
  }else if(plan.mode==='definition'){
    let skipped=0;
    for(const sentence of text.split(/(?<=[。！？])|\r?\n/).map(x=>x.trim()).filter(Boolean)){
      const m=sentence.match(/^([^。！？]{1,80}?)とは[、,\s]*(.{3,500}?)(?:のことである|のことです|のことだ|のこと|である|です|をいう)[。．.]?$/);
      if(!m||/^(?:これ|それ|あれ|ここ|そこ)$/.test(m[1].trim())){skipped++;continue;}
      const term=m[1].trim(),definition=m[2].trim();
      if(definition.includes(term)){issues.push('説明に答えが含まれるため除外しました：'+term);continue;}
      push({q:'「'+definition+'」という説明に当てはまる語句は？',a:term},sentence,'definition:'+term);
    }
    if(skipped)issues.push(`${skipped}文は「○○とは〜です／である／のこと」の形でないため除外しました。`);
  }else throw Error('対応していない作り方です。');
  if(plan.mode==='cloze')for(const [group,total] of groups)if(total>1)issues.push('複数の文にあります。候補を1つ選んでください：'+group.slice(7));
  let selected=0;for(const c of candidates){c.ambiguous=groups.get(c.group)>1;c.selected=!c.ambiguous&&selected<plan.count;if(c.selected)selected++;}
  if(candidates.some(c=>c.ambiguous)&&plan.mode!=='cloze')issues.push('同じ語句に異なる説明があります。原文を確認して候補を1つずつ選んでください。');
  if(truncated)issues.push('候補が200件を超えました。文章・答えの範囲を狭めてください。');
  if(!candidates.length)issues.push('この作り方に合う候補がありません。原文か作り方を確認してください。');
  return {plan,candidates,issues:[...new Set(issues)],selected};
}
function chosen(result){
  const selected=result.candidates.filter(c=>c.selected);
  if(!selected.length)throw Error('追加する候補を選んでください。');
  if(selected.length>result.plan.count)throw Error(`候補は指定した${result.plan.count}問まで選んでください。`);
  const groups=new Set();for(const c of selected){if(groups.has(c.group))throw Error('同じ答えの候補は1つずつ選んでください。');groups.add(c.group);}
  return selected.map(c=>c.card);
}
return {parse,generate,chosen,termsFrom};
});
