/* Optional Spark sharing. Firebase web configuration is public, never an admin credential. */
window.MARKER_FIREBASE_CONFIG=Object.freeze({apiKey:'AIzaSyDKYFDCmiYsqBNtwoQlM644dwEgowwmifA',authDomain:'marker-study.firebaseapp.com',projectId:'marker-study',appId:'1:842405220163:web:e1588b68c7695c594c29f6'});
