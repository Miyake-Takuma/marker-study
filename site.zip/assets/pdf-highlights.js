/* PDF annotation + visible yellow detection. Documents and OCR stay on this device. */
(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'));else root.MarkerPDF=factory(root.MarkerCore);})(typeof window==='object'?window:globalThis,function(core){
 'use strict';
 const normalizeRect=r=>[Math.min(r[0],r[2]),Math.min(r[1],r[3]),Math.max(r[0],r[2]),Math.max(r[1],r[3])];
 const area=r=>Math.max(0,r[2]-r[0])*Math.max(0,r[3]-r[1]);
 const intersection=(a,b)=>Math.max(0,Math.min(a[2],b[2])-Math.max(a[0],b[0]))*Math.max(0,Math.min(a[3],b[3])-Math.max(a[1],b[1]));
 function yellowAnnotation(color){if(!color||color.length<3)return false;const scale=Math.max(...color)>1?1:255;return core.yellow(color[0]*scale,color[1]*scale,color[2]*scale,{sensitivity:'sensitive'});}
 function annotationRects(annotation){
  const raw=annotation.quadPoints,rects=[];
  if(raw?.length){let points=Array.from(raw).flat(Infinity);if(points[0]&&typeof points[0]==='object')points=points.flatMap(p=>[p.x,p.y]);
   for(let i=0;i+7<points.length;i+=8){const p=points.slice(i,i+8);if(!p.every(Number.isFinite))continue;const xs=[p[0],p[2],p[4],p[6]],ys=[p[1],p[3],p[5],p[7]];rects.push([Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]);}
  }
  if(!rects.length&&annotation.rect?.length===4&&Array.from(annotation.rect).every(Number.isFinite))rects.push(normalizeRect(annotation.rect));
  return rects;
 }
 function multiply(a,b){return [a[0]*b[0]+a[2]*b[1],a[1]*b[0]+a[3]*b[1],a[0]*b[2]+a[2]*b[3],a[1]*b[2]+a[3]*b[3],a[0]*b[4]+a[2]*b[5]+a[4],a[1]*b[4]+a[3]*b[5]+a[5]];}
 function transformedRect(rect,matrix){const points=[[rect[0],rect[1]],[rect[0],rect[3]],[rect[2],rect[1]],[rect[2],rect[3]]].map(([x,y])=>[matrix[0]*x+matrix[2]*y+matrix[4],matrix[1]*x+matrix[3]*y+matrix[5]]);return [Math.min(...points.map(p=>p[0])),Math.min(...points.map(p=>p[1])),Math.max(...points.map(p=>p[0])),Math.max(...points.map(p=>p[1]))];}
 function rectangularPaths(data){
  // PDF.js 5.4 uses compact move/line/curve/close commands (0/1/2/3).
  if(!Array.isArray(data)&&!ArrayBuffer.isView(data))return [];
  const rects=[];let points=[],curved=false;
  for(let i=0;i<data.length;){const op=data[i++];
   if(op===0){points=[[data[i++],data[i++]]];curved=false;}
   else if(op===1)points.push([data[i++],data[i++]]);
   else if(op===2){i+=6;curved=true;}
   else if(op===3){if(points.length===5&&points[0][0]===points[4][0]&&points[0][1]===points[4][1])points.pop();
    if(!curved&&points.length===4&&points.flat().every(Number.isFinite)){const xs=[...new Set(points.map(p=>p[0]))],ys=[...new Set(points.map(p=>p[1]))];if(xs.length===2&&ys.length===2&&points.every((p,j)=>{const q=points[(j+1)%4];return (p[0]===q[0])!==(p[1]===q[1]);}))rects.push([Math.min(...xs),Math.min(...ys),Math.max(...xs),Math.max(...ys)]);}
    points=[];curved=false;
   }else break;
  }
  return rects;
 }
 function graphicsRegions(operators,OPS,viewport){
  const markers=[],images=[],stack=[];let state={matrix:[1,0,0,1,0,0],yellow:false,alpha:1};
  const save=()=>stack.push({...state,matrix:[...state.matrix]}),restore=()=>{if(stack.length)state=stack.pop();};
  const toView=r=>transformedRect(r,multiply(viewport.transform,state.matrix));
  const fills=new Set([OPS.fill,OPS.eoFill,OPS.fillStroke,OPS.eoFillStroke,OPS.closeFillStroke,OPS.closeEOFillStroke]);
  for(let i=0;i<operators.fnArray.length;i++){const op=operators.fnArray[i],args=operators.argsArray[i]||[];
   if(op===OPS.save)save();else if(op===OPS.restore)restore();
   else if(op===OPS.transform)state.matrix=multiply(state.matrix,args);
   else if(op===OPS.paintFormXObjectBegin){save();if(args[0])state.matrix=multiply(state.matrix,args[0]);}
   else if(op===OPS.paintFormXObjectEnd)restore();
   else if(op===OPS.beginGroup){save();if(args[0]?.matrix)state.matrix=multiply(state.matrix,args[0].matrix);}
   else if(op===OPS.endGroup)restore();
   else if(op===OPS.setFillRGBColor){const value=args[0];state.yellow=typeof value==='string'&&/^#[0-9a-f]{6}$/i.test(value)?yellowAnnotation([parseInt(value.slice(1,3),16),parseInt(value.slice(3,5),16),parseInt(value.slice(5,7),16)]):yellowAnnotation(args);}
   else if([OPS.setFillGray,OPS.setFillTransparent,OPS.setFillColorN,OPS.setFillCMYKColor].includes(op))state.yellow=false;
   else if(op===OPS.setGState){for(const [key,value] of args[0]||[])if(key==='ca')state.alpha=value;}
   else if(op===OPS.constructPath&&fills.has(args[0])&&state.yellow&&state.alpha>.03){
    for(const rect of rectangularPaths(args[1]?.[0])){const mapped=toView(rect);if(area(mapped)>1&&area(mapped)<viewport.width*viewport.height*.28)markers.push({source:'vector',rects:[mapped]});}
   }else if(op===OPS.paintImageXObject||op===OPS.paintInlineImageXObject)images.push(toView([0,0,1,1]));
   else if(op===OPS.paintImageXObjectRepeat){const [,sx,sy,positions]=args;for(let j=0;j<positions.length;j+=2)images.push(transformedRect([0,0,1,1],multiply(multiply(viewport.transform,state.matrix),[sx,0,0,sy,positions[j],positions[j+1]])));}
  }
  return {markers,images};
 }
 function imageExclusions(images,pageArea,textLength,digitalDocument,includeImages){
  if(includeImages||!digitalDocument)return [];
  // A page-sized scan still needs OCR, even in a mixed text/scan document.
  if(textLength<80&&images.some(r=>area(r)>pageArea*.55))return [];
  return images;
 }
 function highlightPrompt(fileName,hits,pages,budget){
  const list=hits.map((h,i)=>`${i+1}. 【${h.page}ページ】正解候補：${h.answer.trim()}`).join('\n');
  const prefix=`【黄色マーカーの候補を利用者が確認／${fileName}】\n以下の確認済み語句だけを答えにしてください。読み取り間違いや前後の文脈は元PDFで確認し、根拠がなければ問題を作らないでください。\n${list}\n\n【本文の参考情報（同じページの重複を省略）】`;
  const contexts=[...new Set(hits.map(h=>h.page))].map(n=>({label:`\n\n【${n}ページの本文】\n`,text:pages.find(p=>p.page===n)?.text||'文字データなし。画像・OCRの語句の文脈は、利用者が添付した元PDFで確認すること。'}));
  const note='\n\n※本文の参考情報は一部省略しています。添付した元PDFで前後の文脈を確認してください。';
  const available=budget-prefix.length-contexts.reduce((sum,c)=>sum+c.label.length,0)-note.length;
  if(available<0)return null;
  const cap=Math.min(1500,Math.floor(available/Math.max(1,contexts.length))),truncated=contexts.some(c=>c.text.length>cap);
  return prefix+contexts.map(c=>c.label+c.text.slice(0,cap)).join('')+(truncated?note:'');
 }
 function textForRects(items,styles,viewport,rects,measure){
  const selected=[];
  for(const item of items){if(!item.str||!item.transform)continue;
   const t=multiply(viewport.transform,item.transform),style=styles[item.fontName]||{},vertical=style.vertical===true;
   const axis=vertical?[-t[2],-t[3]]:[t[0],t[1]],axisLength=Math.hypot(...axis)||1,ux=axis[0]/axisLength,uy=axis[1]/axisLength;
   const upLength=Math.hypot(t[2],t[3])||1,upx=vertical?-uy:t[2]/upLength,upy=vertical?ux:t[3]/upLength;
   const h=Math.max(1,upLength);
   const length=Math.max(1,Math.abs(vertical?item.height:item.width)*(viewport.scale||1));
   const chars=Array.from(item.str),widths=chars.map(c=>Math.max(.01,measure(c,style,h))),total=widths.reduce((a,b)=>a+b,0)||1;
   let offset=0,text='';
   chars.forEach((c,i)=>{const start=length*offset/total,end=length*(offset+widths[i])/total;offset+=widths[i];
    const corners=[-.15,.9].flatMap(r=>[start,end].map(pos=>[t[4]+ux*pos+upx*h*r,t[5]+uy*pos+upy*h*r]));
    const glyph=[Math.min(...corners.map(p=>p[0])),Math.min(...corners.map(p=>p[1])),Math.max(...corners.map(p=>p[0])),Math.max(...corners.map(p=>p[1]))];
    const cx=(glyph[0]+glyph[2])/2,cy=(glyph[1]+glyph[3])/2;
    if(rects.some(r=>cx>=r[0]&&cx<=r[2]&&cy>=r[1]&&cy<=r[3]))text+=c;
   });
   if(text.trim())selected.push(text+(item.hasEOL?'\n':''));
  }
  return selected.join('').replace(/[ \t]+/g,' ').trim().slice(0,350);
 }
 function mergeCandidates(annotationCandidates,visualCandidates){
  const result=annotationCandidates.map(x=>({...x}));
  for(const visual of visualCandidates){const overlap=result.some(existing=>existing.rects.some(a=>visual.rects.some(b=>intersection(a,b)/Math.max(1,Math.min(area(a),area(b)))>.28)));if(!overlap)result.push(visual);}
  return result;
 }
 function crop(canvas,rect,preview=false){
  const pad=Math.max(4,(rect[3]-rect[1])*.22),x=Math.max(0,Math.floor(rect[0]-pad)),y=Math.max(0,Math.floor(rect[1]-pad)),w=Math.max(1,Math.min(canvas.width-x,Math.ceil(rect[2]-rect[0]+2*pad))),h=Math.max(1,Math.min(canvas.height-y,Math.ceil(rect[3]-rect[1]+2*pad)));
  const scale=preview?Math.min(1,500/w,160/h):Math.min(3,Math.max(1,75/h),2200/w);
  const target=document.createElement('canvas');target.width=Math.max(1,Math.round(w*scale));target.height=Math.max(1,Math.round(h*scale));
  const ctx=target.getContext('2d',{willReadFrequently:true});ctx.fillStyle='#fff';ctx.fillRect(0,0,target.width,target.height);ctx.drawImage(canvas,x,y,w,h,0,0,target.width,target.height);
  if(!preview){const pixels=ctx.getImageData(0,0,target.width,target.height);for(let i=0;i<pixels.data.length;i+=4){let r=pixels.data[i],g=pixels.data[i+1],b=pixels.data[i+2];const gray=core.yellow(r,g,b,{sensitivity:'sensitive'})?255:Math.round(.299*r+.587*g+.114*b);pixels.data[i]=pixels.data[i+1]=pixels.data[i+2]=gray;}ctx.putImageData(pixels,0,0);}
  return target;
 }
 async function renderRegion(page,oldViewport,rect){
  const baseWidth=(rect[2]-rect[0])/oldViewport.scale,baseHeight=(rect[3]-rect[1])/oldViewport.scale,scale=Math.min(3,1800/Math.max(1,baseWidth),400/Math.max(1,baseHeight));
  const viewport=page.getViewport({scale}),factor=scale/oldViewport.scale,pad=12,canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.ceil((rect[2]-rect[0])*factor)+pad*2);canvas.height=Math.max(1,Math.ceil((rect[3]-rect[1])*factor)+pad*2);
  await page.render({canvasContext:canvas.getContext('2d'),viewport,transform:[1,0,0,1,pad-rect[0]*factor,pad-rect[1]*factor],background:'#ffffff'}).promise;
  return canvas;
 }
 let ocrScriptPromise=null;
 async function loadOCR(){
  if(window.Tesseract)return window.Tesseract;
  if(!ocrScriptPromise)ocrScriptPromise=new Promise((resolve,reject)=>{const script=document.createElement('script');script.src=new URL('assets/vendor/ocr/tesseract.min.js',document.baseURI).href;script.onload=()=>window.Tesseract?resolve(window.Tesseract):reject(new Error('OCRを開始できません'));script.onerror=()=>reject(new Error('OCRファイルを読み込めません'));document.head.appendChild(script);}).catch(err=>{ocrScriptPromise=null;throw err;});
  return ocrScriptPromise;
 }
 function createOCRWorker(Tesseract,workerOptions,timeoutMs=60000){
  // Tesseract 6 can leave createWorker pending when language initialization fails.
  // Surface its error callback and bound the wait so manual correction stays usable.
  return new Promise((resolve,reject)=>{let abandoned=false;
   const fail=err=>{abandoned=true;clearTimeout(timer);reject(err instanceof Error?err:new Error(String(err)));};
   const timer=setTimeout(()=>fail(new Error('OCRの準備が時間内に終わりませんでした')),timeoutMs);
   Promise.resolve().then(()=>Tesseract.createWorker(['jpn','eng'],1,{...workerOptions,errorHandler:fail})).then(worker=>{clearTimeout(timer);if(abandoned){Promise.resolve(worker.terminate()).catch(()=>{});return;}resolve(worker);},fail);
  });
 }
 async function analyze(doc,options={}){
  const pages=[],highlights=[];let detected=0,unmatched=0,visualCount=0,vectorCount=0,ignoredImages=0,ocrCount=0,ocrWorker=null,ocrFailed='',cancelled=false,truncated=false;
  const stopped=()=>options.cancelled?.()===true,progress=message=>options.progress?.(message),limit=Math.min(doc.numPages,30);
  const measureCanvas=document.createElement('canvas'),measureContext=measureCanvas.getContext('2d');
  const measure=(char,style,height)=>{measureContext.font=`${height}px ${style.fontFamily||'sans-serif'}`;return measureContext.measureText(char).width;};
  try{
   const prepared=[];
   for(let n=1;n<=limit;n++){
    if(stopped()){cancelled=true;break;}progress(`${n} / ${limit}ページ：PDFのマーカー情報を調べています…`);
    const page=await doc.getPage(n),base=page.getViewport({scale:1}),scale=Math.min(2.5,1800/base.width,Math.sqrt(2400000/(base.width*base.height))),viewport=page.getViewport({scale});
    const content=await page.getTextContent(),items=content.items.filter(x=>typeof x.str==='string'&&x.str.trim()),text=items.map(x=>x.str+(x.hasEOL?'\n':' ')).join('').trim().slice(0,12000);
    // Read paths before rendering: PDF.js replaces their numeric data with Path2D.
    const graphics=graphicsRegions(await page.getOperatorList(),options.OPS||window.pdfjsLib.OPS,viewport),annotations=await page.getAnnotations({intent:'display'});
    prepared.push({page,viewport,content,items,text,graphics,annotations});
   }
   const digitalDocument=prepared.some(p=>p.graphics.markers.length>0&&p.text.length>40);
   for(let index=0;index<prepared.length;index++){
    if(stopped()){cancelled=true;break;}const n=index+1,{page,viewport,content,items,text,graphics,annotations}=prepared[index];progress(`${n} / ${limit}ページ：黄色を探しています…`);
    const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);const ctx=canvas.getContext('2d',{willReadFrequently:true});
    await page.render({canvasContext:ctx,viewport,background:'#ffffff'}).promise;
    const marked=[];
    for(const ann of annotations){if(String(ann.subtype).toLowerCase()!=='highlight'||!yellowAnnotation(ann.color))continue;
     const rects=annotationRects(ann).map(r=>normalizeRect(viewport.convertToViewportRectangle(r)));if(rects.length){marked.push({rects,source:'annotation'});detected++;}
    }
    const scan=document.createElement('canvas'),ratio=Math.min(1,1200/canvas.width,Math.sqrt(1400000/(canvas.width*canvas.height)));scan.width=Math.max(1,Math.round(canvas.width*ratio));scan.height=Math.max(1,Math.round(canvas.height*ratio));const sc=scan.getContext('2d',{willReadFrequently:true});sc.drawImage(canvas,0,0,scan.width,scan.height);
    const excluded=imageExclusions(graphics.images,viewport.width*viewport.height,text.length,digitalDocument,options.includeImages);ignoredImages+=excluded.length;sc.fillStyle='#fff';for(const r of excluded)sc.fillRect(r[0]*ratio,r[1]*ratio,(r[2]-r[0])*ratio,(r[3]-r[1])*ratio);
    const boxes=core.yellowBoxes(sc.getImageData(0,0,scan.width,scan.height).data,scan.width,scan.height,{sensitivity:options.sensitivity}).filter(b=>b.width*b.height<scan.width*scan.height*.28);
    const visible=boxes.map(b=>({source:'visual',rects:[[b.x/ratio,b.y/ratio,(b.x+b.width)/ratio,(b.y+b.height)/ratio]]}));
    const candidates=mergeCandidates(mergeCandidates(marked,graphics.markers),visible).sort((a,b)=>{const ar=a.rects[0],br=b.rects[0];return Math.abs(ar[1]-br[1])<Math.min(ar[3]-ar[1],br[3]-br[1])*.5?ar[0]-br[0]:ar[1]-br[1];});
    for(const candidate of candidates){
     if(stopped()){cancelled=true;break;}if(highlights.length>=150){truncated=true;break;}
     let answer=textForRects(items,content.styles,viewport,candidate.rects,measure),method='pdf-text',confidence=null;
     const rect=[Math.min(...candidate.rects.map(r=>r[0])),Math.min(...candidate.rects.map(r=>r[1])),Math.max(...candidate.rects.map(r=>r[2])),Math.max(...candidate.rects.map(r=>r[3]))];
     let thumbnail=crop(canvas,rect,true).toDataURL('image/jpeg',.82);
     if(!answer&&!ocrFailed){
      progress(`${n} / ${limit}ページ：候補${highlights.length+1}の文字を読んでいます…`);
      try{
       if(!ocrWorker){const Tesseract=await loadOCR(),url=p=>new URL('assets/vendor/ocr/'+p,document.baseURI).href;ocrWorker=await createOCRWorker(Tesseract,{workerPath:url('worker.min.js'),corePath:url('core'),langPath:url('languages'),gzip:false,workerBlobURL:false,cacheMethod:'none'});await ocrWorker.setParameters({tessedit_pageseg_mode:'7',preserve_interword_spaces:'1',user_defined_dpi:'200'});}
       await ocrWorker.setParameters({tessedit_pageseg_mode:candidate.rects.length>1?'6':'7'});
       let input;
       if(viewport.scale<1.8){const sharp=await renderRegion(page,viewport,rect);thumbnail=crop(sharp,[0,0,sharp.width,sharp.height],true).toDataURL('image/jpeg',.82);input=crop(sharp,[0,0,sharp.width,sharp.height]);sharp.width=sharp.height=1;}else input=crop(canvas,rect);
       const result=await ocrWorker.recognize(input);input.width=input.height=1;answer=String(result.data.text||'').replace(/\s+/g,' ').trim().slice(0,350);confidence=Math.round(result.data.confidence||0);method='ocr';ocrCount++;
      }catch(err){ocrFailed='文字認識を開始できませんでした。切り抜きを見て語句を入力してください。';method='unread';}
     }
     if(!answer){unmatched++;method='unread';}if(candidate.source==='visual')visualCount++;if(candidate.source==='vector')vectorCount++;
     highlights.push({page:n,answer,context:answer&&text?text.slice(Math.max(0,text.indexOf(answer)-150),Math.max(0,text.indexOf(answer)-150)+600):'',thumbnail,source:candidate.source,method,confidence,selected:!!answer,rects:candidate.rects});
    }
    const preview=document.createElement('canvas'),previewScale=Math.min(1,850/canvas.width);preview.width=Math.max(1,Math.round(canvas.width*previewScale));preview.height=Math.max(1,Math.round(canvas.height*previewScale));const pc=preview.getContext('2d');pc.drawImage(canvas,0,0,preview.width,preview.height);pc.strokeStyle='#7759F8';pc.lineWidth=2;pc.font='bold 14px sans-serif';
    highlights.forEach((h,i)=>{if(h.page!==n)return;h.rects.forEach(r=>{pc.strokeRect(r[0]*previewScale,r[1]*previewScale,(r[2]-r[0])*previewScale,(r[3]-r[1])*previewScale);pc.fillStyle='#7759F8';pc.fillText(String(i+1),r[0]*previewScale,Math.max(14,r[1]*previewScale-2));});});
    pages.push({page:n,text,preview:preview.toDataURL('image/jpeg',.76)});page.cleanup();canvas.width=canvas.height=scan.width=scan.height=1;
    if(cancelled||truncated)break;
   }
  }finally{if(ocrWorker)try{await ocrWorker.terminate();}catch(_){} }
  return {pages,highlights,detected,unmatched,visualCount,vectorCount,ignoredImages,ocrCount,cancelled,truncated,ocrFailed,pageLimited:doc.numPages>limit};
 }
 return {analyze,annotationRects,yellowAnnotation,textForRects,mergeCandidates,multiply,intersection,createOCRWorker,graphicsRegions,rectangularPaths,imageExclusions,highlightPrompt};
});
