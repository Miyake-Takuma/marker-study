/* Keyboard editing shortcuts. Native IME composition and multiline Enter are preserved. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else api.install(root.document);})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const editable='textarea,select,input:not([type="hidden"]):not([type="file"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"])';
 function visible(el){return !el.disabled&&!el.readOnly&&el.getClientRects().length>0;}
 function handle(ev,doc,state={}){if(ev.isComposing||ev.keyCode===229||ev.defaultPrevented)return;const main=doc.getElementById('main'),target=ev.target;if(!main||!main.contains(target))return;
  const editing=target.matches?.(editable),modifier=ev.ctrlKey||ev.metaKey;
  if(editing)state.last=target;
  if(modifier&&!ev.altKey&&ev.key==='Enter'&&editing){ev.preventDefault();const scope=target.form||target.closest('.panel')||main;const fields=Array.from(scope.querySelectorAll(editable)).filter(visible),i=fields.indexOf(target);if(i<0||!fields.length)return;fields[(i+(ev.shiftKey?-1:1)+fields.length)%fields.length].focus();return;}
  if(modifier&&!ev.altKey&&ev.key.toLowerCase()==='s'){ev.preventDefault();if(ev.repeat)return;const field=editing?target:state.last?.isConnected&&main.contains(state.last)?state.last:target;const form=field.form||field.closest?.('form');
   if(form){const submit=form.querySelector('button[type="submit"],input[type="submit"],button:not([type])');if(submit?.disabled)return;form.requestSubmit(submit||undefined);return;}
   const action=field.id==='bulk-text'?main.querySelector('[data-action="bulk-add"]'):field.id==='answer-text'?main.querySelector('[data-action="test-submit"]'):null;
   if(action&&!action.disabled){action.click();return;}doc.dispatchEvent(new CustomEvent('marker-keyboard-status',{detail:'この画面には保存する入力がありません。設定の変更は自動で保存されます。'}));return;}
  if(ev.key==='Escape'&&editing){ev.preventDefault();target.blur();main.focus({preventScroll:true});return;}
  if(ev.key==='Enter'&&!modifier&&!ev.altKey&&target.tagName==='INPUT'&&target.form&&editing){ev.preventDefault();}
 }
 function install(doc){const state={};doc.addEventListener('keydown',ev=>handle(ev,doc,state));}
 return {handle,install};
});
