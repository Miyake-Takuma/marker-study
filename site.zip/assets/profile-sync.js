/* Account-scoped profile cache and conflict-aware synchronization. No study data. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerProfileSync=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 function create({core,storage,onChange=()=>{}}){
  let state={uid:null,profile:null,revision:0,ready:false,saving:false,message:''},adapter=null,unsubscribe=null,epoch=0;
  const emit=()=>onChange({...state});
  const key=uid=>'marker-study-account-profile-v1:'+uid;
  function cache(){try{storage?.setItem(key(state.uid),JSON.stringify({profile:state.profile,revision:state.revision}));}catch(_){}}
  function accept(value){if(!value||!Number.isInteger(value.revision)||value.revision<1)throw Error('アカウントのプロフィールを読み取れませんでした。');const clean=core.profile(value.profile);if(Object.keys(value.profile).length!==4||Object.keys(clean).some(k=>clean[k]!==value.profile[k]))throw Error('アカウントのプロフィール形式を確認してください。');state.profile=clean;state.revision=value.revision;state.ready=true;cache();}
  async function start(account,nextAdapter,guest){
   const token=++epoch;unsubscribe?.();unsubscribe=null;adapter=nextAdapter;
   state={uid:account?.uid||null,profile:null,revision:0,ready:false,saving:false,message:account?'プロフィールを確認しています…':''};
   if(!account){emit();return;}
   try{const value=JSON.parse(storage?.getItem(key(account.uid))||'null');if(value)accept(value);}catch(_){}
   state.ready=false;emit();
   try{
    let value=await adapter.read(account.uid);const wasMissing=!value;
    if(token!==epoch)return;
    if(!value){try{value=await adapter.write(account.uid,state.profile||core.profile(guest),0);}catch(err){value=await adapter.read(account.uid);if(!value)throw err;}}
    if(token!==epoch)return;if(wasMissing)state.revision=0;
    // The first account record may have been created on an empty device. Keep an
    // existing local avatar instead of replacing it with the untouched default.
    const local=state.profile&&(state.profile.image||state.profile.icon!=='📚')?state.profile:core.profile(guest);
    if(value.revision===1&&!value.profile.image&&value.profile.icon==='📚'&&(local.image||local.icon!=='📚')){
     const recovered={...value.profile,image:local.image,icon:local.icon};
     state.profile=recovered;state.revision=1;cache();emit();
     try{value=await adapter.write(account.uid,recovered,1);}
     catch(err){let latest;try{latest=await adapter.read(account.uid);}catch(_){}if(token!==epoch)return;if(latest?.revision>1)value=latest;else throw Error('この端末のアイコンは保護しています。通信を確認して「接続を更新」を押すと、アカウントへの引継ぎを再試行できます。');}
    }
    if(token!==epoch)return;
    if(state.profile&&value.revision<state.revision)throw Error('保存済みより古いプロフィールを受信したため、端末のアイコンを保護しました。接続を更新してください。');
    accept(value);state.message='アカウントと同期しました。';emit();
    unsubscribe=adapter.subscribe(account.uid,value=>{if(token!==epoch||!value||value.revision<state.revision)return;try{accept(value);state.message='アカウントと同期しました。';}catch(err){state.ready=false;state.message=err.message;}emit();},()=>{if(token!==epoch)return;state.message='同期を確認できません。通信を確認して再接続してください。';emit();});
   }catch(err){if(token!==epoch)return;state.ready=false;state.message=err?.code==='permission-denied'?'プロフィール同期の保存先がまだ有効になっていません。':(err.message||'プロフィールを取得できません。通信を確認してください。');emit();}
  }
  async function save(value,expectedRevision){
   if(!state.uid||!state.ready)throw Error('アカウントのプロフィールを取得してから保存してください。');
   if(state.saving)throw Error('保存が終わるまでお待ちください。');
   if(expectedRevision!==state.revision)throw Error('別の端末で変更されています。「最新のプロフィールを表示」で確認してから編集してください。');
   const clean=core.profile(value);if(Object.keys(value).length!==4||Object.keys(clean).some(k=>clean[k]!==value[k]))throw Error('プロフィールの内容を確認してください。');
   const uid=state.uid,token=epoch;state.saving=true;emit();
   try{const saved=await adapter.write(uid,clean,expectedRevision);if(token!==epoch)throw Error('ログインするアカウントが変わりました。現在のプロフィールを確認してください。');if(saved.revision>=state.revision)accept(saved);state.message='すべての端末向けに保存しました。';return saved;}
   catch(err){if(token===epoch)state.message=err.message||'同期できませんでした。入力は残っています。';throw err;}
   finally{if(token===epoch){state.saving=false;emit();}}
  }
  return {start,save,state:()=>({...state,profile:state.profile?{...state.profile}:null})};
 }
 return {create};
});
