// Public connection settings only. Keep empty until the dedicated FREE project is configured.
// Never put a service_role key, sb_secret key, Google secret, or password here.
window.MarkerSharingConfig = {url:'',publishableKey:''};
