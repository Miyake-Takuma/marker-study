/* Tab-separated question entry. Shift+Tab keeps normal keyboard navigation. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else api.install(root.document);})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 function insert(field){if(!field)return;field.setRangeText('\t',field.selectionStart,field.selectionEnd,'end');field.dispatchEvent(new Event('input',{bubbles:true}));field.focus();}
 function keydown(ev){if(ev.target?.id!=='bulk-text'||ev.key!=='Tab'||ev.shiftKey||ev.ctrlKey||ev.altKey||ev.metaKey||ev.isComposing)return;ev.preventDefault();insert(ev.target);}
 function install(doc){doc.addEventListener('keydown',keydown);doc.addEventListener('click',ev=>{if(!ev.target.closest('[data-insert-bulk-tab]'))return;ev.preventDefault();insert(doc.getElementById('bulk-text'));});}
 return {insert,keydown,install};
});
