/* Private account library synchronization. Local saves remain authoritative offline. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerLibrarySync=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 const MAX_BYTES=4000000,PART_SIZE=50000,MAX_PARTS=80;
 function canonical(value){if(Array.isArray(value))return '['+value.map(canonical).join(',')+']';if(value&&typeof value==='object')return '{'+Object.keys(value).sort().map(k=>JSON.stringify(k)+':'+canonical(value[k])).join(',')+'}';return JSON.stringify(value);}
 function hash(value){const text=canonical(value);let a=2166136261,b=5381;for(let i=0;i<text.length;i++){a=Math.imul(a^text.charCodeAt(i),16777619);b=Math.imul(b,33)^text.charCodeAt(i);}return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');}
 function clean(raw,core){if(!raw||raw.version!==1||!Array.isArray(raw.decks))throw Error('同期した問題集の形式を確認してください。');const db=core.database({version:1,decks:raw.decks,exams:[],settings:{},history:raw.history||[],counts:raw.counts||{}});const deleted=raw.deleted||[];if(!Array.isArray(deleted)||deleted.length>5000||deleted.some(id=>typeof id!=='string'||!id||id.length>150))throw Error('削除履歴の形式を確認してください。');const ids=new Set(db.decks.map(d=>d.id));return {version:1,decks:db.decks,history:db.history,counts:db.counts,deleted:[...new Set(deleted)].filter(id=>!ids.has(id)).sort()};}
 function baseline(value,revision){return {revision,decks:Object.fromEntries(value.decks.map(d=>[d.id,hash(d)])),deleted:value.deleted};}
 function merge(local,remote,base={decks:{},deleted:[]}){
  const l=new Map(local.decks.map(d=>[d.id,d])),r=new Map(remote.decks.map(d=>[d.id,d])),deleted=new Set([...local.deleted,...remote.deleted,...(base.deleted||[])]),out=new Map();let conflicts=0;
  function keep(d){const previous=out.get(d.id);if(previous&&canonical(previous)!==canonical(d))throw Error('問題集IDの競合を保護できません。バックアップを保存してください。');out.set(d.id,d);}
  function fork(d){const copy=JSON.parse(JSON.stringify(d)),id='protected-'+hash(d);copy.id=id;copy.title=('【競合保護】'+d.title).slice(0,100);copy.cards.forEach((c,i)=>c.id=id+'-c'+i);(copy.pending||[]).forEach((p,i)=>p.id=id+'-p'+i);keep(copy);conflicts++;}
  for(const id of new Set([...l.keys(),...r.keys(),...Object.keys(base.decks||{})])){
   const left=l.get(id),right=r.get(id),before=base.decks?.[id],lh=left&&hash(left),rh=right&&hash(right);
   const localDeleted=local.deleted.includes(id)&&!left,remoteDeleted=deleted.has(id);if(localDeleted)deleted.add(id);
   if(localDeleted||remoteDeleted){if(left&&lh!==before)fork(left);if(right&&rh!==before&&(!left||rh!==lh))fork(right);continue;}
   if(left&&right){if(lh===rh)keep(right);else if(lh===before)keep(right);else if(rh===before)keep(left);else{keep(right);fork(left);}}
   else if(left)keep(left);else if(right)keep(right);
  }
  for(const id of out.keys())deleted.delete(id);
  const history=new Map(remote.history.map(x=>[x.id,x]));for(const h of local.history){const previous=history.get(h.id);if(previous&&canonical(previous)!==canonical(h))history.set('protected-'+hash(h),{...h,id:'protected-'+hash(h)});else history.set(h.id,h);}
  return {value:{version:1,decks:[...out.values()].sort((a,b)=>a.id.localeCompare(b.id)),deleted:[...deleted].sort(),history:[...history.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id)).slice(-50),counts:{sessions:Math.max(local.counts.sessions,remote.counts.sessions)}},conflicts};
 }
 function pack(value){const raw=JSON.stringify(value);if(new TextEncoder().encode(raw).length>MAX_BYTES)throw Error('無料の同期は1アカウント4MBまでです。端末の問題は残っています。問題集を書き出して保管してください。');const parts=[];for(let i=0;i<raw.length;){let end=Math.min(i+PART_SIZE,raw.length);if(end<raw.length&&/[\uD800-\uDBFF]/.test(raw[end-1]))end--;parts.push(raw.slice(i,end));i=end;}if(parts.length>MAX_PARTS)throw Error('同期するデータが大きすぎます。端末の問題は残っています。');return parts;}
 function unpack(parts){if(!Array.isArray(parts)||!parts.length||parts.length>MAX_PARTS||parts.some(p=>typeof p!=='string'||p.length>PART_SIZE))throw Error('問題集の一部を取得できませんでした。端末の問題は変更していません。');const raw=parts.join('');if(new TextEncoder().encode(raw).length>MAX_BYTES)throw Error('同期データが上限を超えています。');return JSON.parse(raw);}
 function create({core,storage,getLocal,apply,canApply=()=>true,onChange=()=>{},delay=1000}){
  let state={uid:null,busy:false,ready:false,blocked:false,pending:false,revision:0,message:'問題集はこの端末に保存されています。'},adapter=null,base={decks:{},deleted:[]},token=0,timer=null,unsub=null,again=false,running=null,pendingDeletes=[];
  const emit=()=>onChange({...state}),baseKey=uid=>'marker-study-library-base-v1:'+uid,ownerKey='marker-study-library-owner-v1',deleteKey=uid=>'marker-study-library-deletions-v1:'+uid;
  const deletions=()=>[...new Set([...(base.deleted||[]),...pendingDeletes])];
  function markDeleted(ids){if(!state.uid||state.blocked)return false;pendingDeletes=[...new Set([...pendingDeletes,...ids])];try{storage.setItem(deleteKey(state.uid),JSON.stringify(pendingDeletes));}catch(_){state.blocked=true;state.message='削除履歴を端末に保存できません。アカウント側は削除していません。';emit();return false;}notify();return true;}
  function watch(uid,generation){if(unsub||!adapter.subscribe)return;unsub=adapter.subscribe(uid,revision=>{if(generation===token&&revision>state.revision)notify();},()=>{if(generation!==token)return;unsub=null;state.ready=false;state.pending=true;state.message='同期接続を確認できません。端末の問題は残っています。';emit();});}
  function notify(){if(!state.uid||state.blocked)return;state.pending=true;if(!state.busy)state.message='端末に保存済み・アカウントへの同期待ちです。';emit();clearTimeout(timer);timer=setTimeout(()=>sync(),delay);}
  async function sync(){
   clearTimeout(timer);if(!state.uid||state.blocked)return false;if(state.busy){again=true;return running;}
   const generation=token,uid=state.uid;state.busy=true;state.pending=true;state.message='問題集を同期しています…';emit();
   running=(async()=>{try{
    for(let attempt=0;attempt<4;attempt++){
     again=false;const remoteResult=await adapter.read(uid);if(generation!==token)return false;
     const remote=clean(remoteResult?.value||{version:1,decks:[]},core),revision=remoteResult?.revision||0;
     const local=clean({...getLocal(),deleted:deletions()},core),merged=merge(local,remote,base),value=clean(merged.value,core);pack(value);
     if(!canApply()){state.message='入力・学習が終わってから同期します。端末への保存は続いています。';return false;}
     if(canonical(local)!==canonical(value)){await apply(value);if(generation!==token)return false;}
     let savedRevision=revision;
     if(canonical(remote)!==canonical(value)){
      try{const saved=await adapter.write(uid,value,revision);if(generation!==token)return false;savedRevision=saved.revision;}
      catch(err){if(err.code==='library/conflict')continue;throw err;}
     }
     pendingDeletes=pendingDeletes.filter(id=>!value.deleted.includes(id));storage.setItem(deleteKey(uid),JSON.stringify(pendingDeletes));base=baseline(value,savedRevision);storage.setItem(baseKey(uid),JSON.stringify(base));state.revision=savedRevision;state.ready=true;watch(uid,generation);
     state.pending=canonical(clean({...getLocal(),deleted:deletions()},core))!==canonical(value);
     state.message=merged.conflicts?'競合した問題集は両方残しました。「競合保護」の問題集を確認してください。':state.pending?'端末の追加変更を同期待ちです。':`問題集を同期しました（${value.decks.length}冊）。`;
     return true;
    }
    throw Error('ほかの端末の更新が続いています。端末の問題を保護しています。少し待って再試行してください。');
   }catch(err){if(generation===token){state.ready=false;state.pending=true;state.message=String(err?.code||'').includes('permission-denied')?'問題集の同期先がまだ有効になっていません。端末の問題は残っています。':String(err?.code||'').match(/quota|resource-exhausted/)?'無料枠の上限で同期を停止しました。端末の問題は残っています。自動課金はありません。':(err.message||'通信できません。端末の問題は残っています。');}return false;}
   finally{if(generation===token){state.busy=false;emit();if(again||state.ready&&state.pending)notify();}}})();return running;
  }
  async function start(account,nextAdapter){
   token++;clearTimeout(timer);unsub?.();unsub=null;adapter=nextAdapter;again=false;state={uid:account?.uid||null,busy:false,ready:false,blocked:false,pending:false,revision:0,message:account?'問題集を確認しています…':'問題集はこの端末に保存されています。'};base={decks:{},deleted:[]};pendingDeletes=[];
   if(!account){emit();return;}
   try{const owner=storage.getItem(ownerKey);if(owner&&owner!==account.uid){state.blocked=true;state.message='別のアカウントの端末データが残っています。勝手に送信しません。「この端末の問題も追加して同期」で確認してください。';emit();return;}
    storage.setItem(ownerKey,account.uid);const saved=JSON.parse(storage.getItem(baseKey(account.uid))||'null');if(saved&&saved.decks&&typeof saved.decks==='object'&&Array.isArray(saved.deleted))base=saved;const pending=JSON.parse(storage.getItem(deleteKey(account.uid))||'[]');if(!Array.isArray(pending)||pending.length>5000||pending.some(id=>typeof id!=='string'||!id||id.length>150))throw Error('deletions');pendingDeletes=pending;
   }catch(_){state.blocked=true;state.message='同期用の保存先を確保できません。端末のバックアップと保存設定を確認してください。';emit();return;}
   emit();const generation=token;await sync();if(generation!==token)return;
   if(state.ready)watch(account.uid,generation);
  }
  async function claim(){if(!state.uid||!state.blocked)return;storage.setItem(ownerKey,state.uid);return start({uid:state.uid},adapter);}
  return {start,sync,notify,markDeleted,claim,state:()=>({...state})};
 }
 return {create,clean,merge,baseline,pack,unpack,canonical,MAX_PARTS};
});
