/* Local profile images: decode, crop and re-encode without uploading originals. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerAvatar=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 async function prepare(file,env=globalThis){
  if(!file)return null;
  if(file.size<=0||file.size>10*1024*1024)throw Error('10MB以下の画像を選んでください。');
  const types=['image/jpeg','image/png','image/webp'];
  if(!types.includes(file.type)&&!(file.type===''&&/\.(jpe?g|png|webp)$/i.test(file.name||'')))throw Error('JPEG・PNG・WebPの画像を選んでください。');
  const url=env.URL.createObjectURL(file),img=new env.Image();let timer;
  try{
   await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(Error('画像を読み込めませんでした。JPEGやPNGで保存し直して試してください。'));timer=setTimeout(()=>reject(Error('画像の読み込みに時間がかかっています。小さい画像で試してください。')),15000);img.src=url;});
   const w=img.naturalWidth,h=img.naturalHeight;if(!w||!h||w*h>40000000)throw Error('画像が大きすぎます。4000万画素以下の画像を選んでください。');
   const canvas=env.document.createElement('canvas');canvas.width=canvas.height=256;const ctx=canvas.getContext('2d');if(!ctx)throw Error('このブラウザでは画像を調整できません。');
   const side=Math.min(w,h);ctx.fillStyle='#ffffff';ctx.fillRect(0,0,256,256);ctx.drawImage(img,(w-side)/2,(h-side)/2,side,side,0,0,256,256);
   const result=canvas.toDataURL('image/jpeg',.85);if(result.length>100000||!/^data:image\/jpeg;base64,\/9j\/[A-Za-z0-9+/]*={0,2}$/.test(result))throw Error('画像を小さくできませんでした。別の画像を試してください。');return result;
  }finally{clearTimeout(timer);img.onload=img.onerror=null;img.src='';env.URL.revokeObjectURL(url);}
 }
 return {prepare};
});
