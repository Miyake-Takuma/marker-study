/* Screen history. Draft text stays in memory; browser history contains route IDs only. */
(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.MarkerNavigation=api;})(typeof window==='object'?window:globalThis,function(){
 'use strict';
 function create(options){
  const history=options.history,storage=options.storage,views=new Map(),routes=new Map();
  const valid=s=>s&&s.markerStudyNavigation===1&&typeof s.session==='string'&&Number.isInteger(s.index)&&s.index>=0&&s.route&&typeof s.route.screen==='string';
  const state=history?.state;
  let current=valid(state)?state:{markerStudyNavigation:1,session:'nav-'+Date.now()+'-'+Math.random().toString(36).slice(2),index:0,route:options.initial};
  let maximum=current.index;
  try{const saved=JSON.parse(storage?.getItem('marker-study-navigation')||'null');if(saved?.session===current.session&&Number.isInteger(saved.maximum)&&saved.maximum>=maximum)maximum=saved.maximum;}catch(_){}
  function saveMaximum(){try{storage?.setItem('marker-study-navigation',JSON.stringify({session:current.session,maximum}));}catch(_){} }
  function write(replace){try{history?.[replace?'replaceState':'pushState'](current,'');}catch(_){}saveMaximum();}
  function capture(discard){views.set(current.index,options.capture({discardDraft:!!discard}));routes.set(current.index,current.route);}
  function restore(){options.restore(current.route,views.get(current.index)||{});}
  function pop(event){
   if(!valid(event.state)||event.state.session!==current.session)return;
   capture(false);current=event.state;maximum=Math.max(maximum,current.index);saveMaximum();restore();
  }
  options.listen?.('popstate',pop);
  if(history&&'scrollRestoration' in history)history.scrollRestoration='manual';
  routes.set(current.index,current.route);write(true);
  return {
   start:restore,
   navigate(route,opts={}){
    if(JSON.stringify(route)===JSON.stringify(current.route)&&!opts.replace){if(opts.view){views.set(current.index,opts.view);restore();return true;}return false;}
    capture(opts.discardDraft);
    current={...current,index:opts.replace?current.index:current.index+1,route};if(!opts.replace)maximum=current.index;
    if(opts.replace)views.delete(current.index);
    else for(const i of [...views.keys()])if(i>=current.index)views.delete(i);
    routes.set(current.index,route);if(opts.view)views.set(current.index,opts.view);write(!!opts.replace);restore();return true;
   },
   update(route){current={...current,route};routes.set(current.index,route);write(true);},
   back(){if(current.index<=0)return false;if(history)history.back();else pop({state:{...current,index:current.index-1,route:routes.get(current.index-1)}});return true;},
   forward(){if(current.index>=maximum)return false;if(history)history.forward();else pop({state:{...current,index:current.index+1,route:routes.get(current.index+1)}});return true;},
   canBack:()=>current.index>0,
   canForward:()=>current.index<maximum,
   hasDrafts:()=>[...views.values()].some(view=>view.hasUnsavedInput),
   route:()=>current.route
  };
 }
 return {create};
});
