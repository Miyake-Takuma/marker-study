# 外部依存・費用

アプリは静的HTML・CSS・JavaScriptで動きます。AI API、認証サーバー、広告、決済処理、分析トラッカーは使っていません。

|依存|利用箇所|費用・通信|
|---|---|---|
|Mozilla PDF.js 5.4.54 legacy build|PDFの描画・文字・注釈抽出|Apache-2.0、アプリに同梱。実行時CDN不要|
|PDF.js CMaps / standard_fonts|日本語などのPDF文字抽出・描画|同梱。フォント個別のライセンスを同じフォルダーに保持。初回アプリ保存後は通信不要|
|Tesseract.js 6.0.1 / tesseract.js-core 6.0.0|PDFの黄色部分を端末内で文字認識|Apache-2.0。Worker・WASM内蔵JSを同梱、API・外部OCRサーバー不要|
|tesseract-ocr/tessdata_fast 日本語・英語モデル|OCRの認識辞書|Apache-2.0、同梱。自動ダウンロード・自動更新なし|
|ブラウザの保存・Service Worker|学習記録・オフライン起動|ブラウザ標準機能。OSによる削除・容量制限あり|
|外部AIのチャットサイト|本人が選んで開く手動連携|外部サービスの無料利用枠・規約に依存。API接続なし|
|Node.js|開発時のローカル確認・テスト・公開用コピー作成|無料。公開先で実行不要|
|Windows標準.NET Framework・Chrome/Edge|PC用起動アプリと独立ウィンドウ|インストール済み機能を利用。Node.js不要。独自の課金・有料サーバーなし|

PDF.jsのライセンスはassets/vendor/LICENSEと各ファイル冒頭に保持しています。公式配布元は https://registry.npmjs.org/pdfjs-dist/-/pdfjs-dist-5.4.54.tgz です。依存は固定版で、自動更新しません。古い3.11.174から変更し、PDF解析時はisEvalSupported:falseも設定しました。[Mozillaのセキュリティ情報](https://github.com/mozilla/pdf.js/security/advisories/GHSA-wgrm-67xf-hhpq)。

OCRの公式配布元は[Tesseract.js](https://github.com/naptha/tesseract.js)、[Tesseract.js Core](https://github.com/naptha/tesseract.js-core)、[tessdata_fast](https://github.com/tesseract-ocr/tessdata_fast)です。ライセンスはassets/vendor/ocr/TESSERACT-JS-LICENSE、core/LICENSE、languages/LICENSEに保持しています。モデルは取得したファイルを同梱し、自動更新しません。取得時のSHA-256はOCR-MODELS.sha256に記録しています。

OCR関連ファイルは合計約24MBです。初回のアプリ保存時に取得し、以後はオフラインでも使用します。PDF・切り抜き・OCR結果は解析中のメモリーに置き、Service Workerや外部サーバーには保存しません。利用者が確認してAI指示文に追加した語句は従来の入力欄に入ります。

無料の公開先についてはDEPLOY.mdを参照してください。無料サービスの将来の継続・上限は保証しません。上限を超えても自動的に有料契約へ移行する仕組みは含めません。


## Firebase JavaScript SDK (optional online sharing)
Firebase SDK 12.5.0 is loaded on request from Google gstatic. Apache-2.0. Source and license: https://github.com/firebase/firebase-js-sdk . Authentication and Firestore only; no Analytics, Storage, Functions or paid AI.
